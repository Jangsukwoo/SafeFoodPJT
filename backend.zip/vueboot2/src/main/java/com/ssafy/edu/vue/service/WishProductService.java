package com.ssafy.edu.vue.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.edu.vue.dao.WishProductDAO;

@Service
public class WishProductService {
	@Autowired
	WishProductDAO wishproductDao;
	
	
	//CRUD
}
